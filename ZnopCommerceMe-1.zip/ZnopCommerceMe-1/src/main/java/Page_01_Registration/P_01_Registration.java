package Page_01_Registration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Page_00_PageBase.P_00_PageBase;

public class P_01_Registration extends P_00_PageBase {
	
public P_01_Registration(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	//Create Method to locate Register button Element 	
	public WebElement Register_Btn(WebDriver driver)  {
		
		return driver.findElement(By.xpath("//a[@href=\"/register?returnUrl=%2F\"]"));
	}

}
