package Test_01_Registration;

import org.testng.annotations.Test;

import Page_01_Registration.P_01_Registration;
import Test_00_TestBase.T_00_TestBase;
import org.testng.annotations.BeforeTest;
import java.sql.Driver;

import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;

public class T_01_Register_NewUSer extends T_00_TestBase { //1-Make inheritance from "T_00_TestBase" Class 
  @Test
  public void Register_NewUSer() throws InterruptedException {
	  //a few Steps only for Checking Steps is correct till moment :
	  System.out.println("Print \"Register\" for Checking Linking between Classes");//To be sure that Links between Class works fine
	  String getURLPLZ = driver.getCurrentUrl(); //get the URL that driver use & print it to be sure that steps is correct & inheritance  works fine 
	  System.out.println("The URL that driver use is "+getURLPLZ);
//==========
//2-Create new Object from "P_01_Registration" Class 
	  P_01_Registration reg = new P_01_Registration(driver);
	  
//3-Call the Register button-Send the Driver-Take Click Action
	  reg.Register_Btn(driver).click();
	  
	  Thread.sleep(2000);
  }

}
