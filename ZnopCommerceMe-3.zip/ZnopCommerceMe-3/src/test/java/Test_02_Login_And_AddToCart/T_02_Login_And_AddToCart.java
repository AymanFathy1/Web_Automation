package Test_02_Login_And_AddToCart;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.Test;


import Page_00_PageBase.P_00_PageBase;
import Page_02_LogIn.P_02_LogIn;
import Page_03_Home_Page.P_03_Home_Page;
import Page_04_Category_Page.P_04_CategoryPage;
import Test_00_TestBase.T_00_TestBase;
import javafx.scene.layout.Priority;

public class T_02_Login_And_AddToCart extends T_00_TestBase { //Make inheritance from "T_00_TestBase" Class [ as TestBase class holds browser & url info]
//Login & Add to Card Scenarios Steps & Actions 	
	
	@Test (priority = 1) //Login first :	
  public void Login ()  throws IOException, InterruptedException  {
	
	//1-Create new Object from "P_02_LogIn" Class as this class holds the "Login_Btn" Element & other Add to Card Elements locators	  
           P_02_LogIn login = new P_02_LogIn(driver);
           
    //2-Call the "loginTab" element ,Send the Driver & Take Click Action
     	  login.loginTab().click();
           
     	 Thread.sleep(1000);
    //3-Call the "Email" element using [Properties file],Send the Driver & Take Action		  
          login.email().sendKeys(getProperty("Email"));  	  
 
    //4-Call the "Password" element using [Properties file],Send the Driver & Take Action		  
    	  login.password().sendKeys(getProperty("Password"));
    	  
    	  Thread.sleep(2000);
    //5-Call the "login_Btn" element using [Properties file],Send the Driver & Take Action		  
          login.login_Btn().click();
	       
          Thread.sleep(2000);
	}         
   
 //=========         
	@Test (priority = 2)  //Then Adding To Cart :	
	  public void Add_ToCart ()  throws IOException, InterruptedException  {       
          P_03_Home_Page home = new P_03_Home_Page(driver);  //create object from "P_03_Home_Page" class as it contain "top menu " element 
          
      	    int menus = new Random().nextInt(home.topMenus("").size()); //Select the menu category randomly 
      	    home.topMenus("").get(menus).click();

      	    P_04_CategoryPage Category = new P_04_CategoryPage(driver); //Create object from "P_04_CategoryPage" as it contai Sub category
      	 if(!Category.sub_category("").isEmpty())
      	  {
      	
      	 int sub_menus = new Random().nextInt(Category.sub_category("").size());
      	
      	 Category.sub_category("").get(sub_menus).click();
      	
      	  }      
     
     	int product = new Random().nextInt(Category.Add_To_Cart().size());
    	
    	Category.Add_To_Cart().get(product).click();
          
  }
	

	
}
