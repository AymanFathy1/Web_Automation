package Test_01_Registration;

import org.testng.annotations.Test;

import Page_01_Registration.P_01_Registration;
import Test_00_TestBase.T_00_TestBase;
import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.Driver;
import java.util.Random;

import org.apache.tools.ant.taskdefs.Sleep;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class T_01_Register_NewUSer extends T_00_TestBase { //Make inheritance from "T_00_TestBase" Class [ as TestBase class holds browser & url info]
	
		
  @Test
  public void Register_NewUSer() throws IOException, InterruptedException {
	  
//	  //a few Steps only for Checking Steps is correct till moment :
//	  System.out.println("Print \"Register\" for Checking Linking between Classes");//To be sure that Links between Class works fine
//	  String getURLPLZ = driver.getCurrentUrl(); //get the URL that driver use & print it to be sure that steps is correct & inheritance  works fine 
//	  System.out.println("The URL that driver use is "+getURLPLZ);
//==========
//Registration Scenarios Steps & Actions 
	  
//*Create new Object from "P_01_Registration" Class as this class holds the "Register_Btn" Element locator
	  P_01_Registration reg = new P_01_Registration(driver);
	  
//1-Call the "Register Tab" element ,Send the Driver & Take Click Action
	  reg.registerTab().click();
	  
//2-Call the "Gender Mail" element ,Send the Driver & Take Click Action	  
	  reg.genderMale().click();
	  
//4-Call the "firstMail" element using [Properties file] ,Send the Driver & Take Action	 	  
	  reg.firstName().sendKeys(getProperty("FirstName"));

//5-Call the "lasttMail" element using [Properties file] ,Send the Driver & Take Action	
	  reg.lastName().sendKeys(getProperty("LastName"));

//6-Call the "Date of birth/Day" element ,Send the Driver & Take Action	
	  
	  Select dropdown = new Select(reg.dateOfBirth_Day()); //Create new object from Select
	  dropdown.getOptions().get(new Random().nextInt(dropdown.getOptions().size())).click(); //use Random() to select the dates randomly 
	  
//7-Call the "Date of birth/Day" element ,Send the Driver & Take Action	
	  
	  dropdown = new Select(reg.dateOfBirth_Month()); //Create new object from Select but no need to add "Select" class word again as it's written above
	  dropdown.getOptions().get(new Random().nextInt(dropdown.getOptions().size())).click(); 
	  
//8-Call the "Date of birth/Day" ,Send the Driver & Take Action	
	  
	  dropdown = new Select(reg.dateOfBirth_Year()); //Create new object from Select but no need to add "Select" class word again as it's written above
	  dropdown.getOptions().get(new Random().nextInt(dropdown.getOptions().size())).click(); 
	
//9-Call the "Email" element using [Properties file],Send the Driver & Take Action		  
	  reg.email().sendKeys(getProperty("Email"));
	  
//10-Call the "Password" element using [Properties file],Send the Driver & Take Action		  
	  reg.password().sendKeys(getProperty("Password"));
	  
	  
//11-Call the "Confirm Password" element using [Properties file],Send the Driver & Take Action		  
	  reg.confirmPassword().sendKeys(getProperty("Password"));
	  
	  
//12-Call the "Register Button" element using [Properties file],Send the Driver & Take Action		  
	  reg.register_Btn().click();

  Thread.sleep(2000);

//13-Call "Register Success Message" Element 
//14-Call "Already Exist Mail Message" Element
	  
	  if(!reg.alreadyExistMail_Msg().isEmpty())
		{
	  assertTrue(reg.alreadyExistMail_Msg().get(0).isDisplayed(), "Email is already exist");
		}
	  else
		{
	  assertTrue(reg.success_Msg().get(0).isDisplayed(), "Your registration completed");
		}
	  
	  Thread.sleep(1000);
  }

}
