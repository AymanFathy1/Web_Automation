//This Class for Login Page Elemnt Locatores 
package Page_02_LogIn;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Page_00_PageBase.P_00_PageBase;

public class P_02_LogIn extends P_00_PageBase  {  //inherit from  "P_00_PageBase" Class

	public P_02_LogIn(WebDriver driver) {   //constructor
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
  //1-Create Method to LOCATE "Login Tab" Element, Then go to "T_02_Login_And_AddToCart" class to execute the TC & take action
	
	public WebElement  loginTab ()
	{	
	return driver.findElement(By.xpath("//a[@href=\"/login?returnUrl=%2F\"]"));	
	}

  //2-Create Method to LOCATE "Login Button" Element, Then go to "T_02_Login_And_AddToCart" class to execute the TC & take action	
	public WebElement  login_Btn ()
	{	
	return driver.findElement(By.xpath("//input[@value=\"Log in\"]"));
	}
	
  //3-Create Method to LOCATE "Email" Element, Then go to "T_02_Login_And_AddToCart" class to execute the TC & take action		
	public WebElement email ()
	{
		return driver.findElement(By.id("Email"));
	}
  //4-Create Method to LOCATE "password" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action   	
	public WebElement password ()
	{
		return driver.findElement(By.id("Password"));
	}
	
}
