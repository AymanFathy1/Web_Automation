package Page_04_Category_Page;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Page_00_PageBase.P_00_PageBase;

public class P_04_CategoryPage extends P_00_PageBase {

	public P_04_CategoryPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

//1-Locating "Sub Category for Category" list element 	
	public List<WebElement> sub_category (String num)
	{	
	return driver.findElements(By.xpath("//div[@class=\"sub-category-item\"]/h2[@class=\"title\"]/a"+num));
	}

//2-Locating "product title"  element 	
	public WebElement product_title (int num)
	{	
	return driver.findElement(By.xpath("(//h2[@class=\"product-title\"])["+num+"]/a"));
	}
//3-Locating "ADD to Cart"  element 	
	public List<WebElement> Add_To_Cart ()
	{	
	return driver.findElements(By.xpath("//input[@value=\"Add to cart\"]"));
	}
	
}

