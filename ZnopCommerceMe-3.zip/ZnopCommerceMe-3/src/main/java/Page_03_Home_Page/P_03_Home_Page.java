package Page_03_Home_Page;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Page_00_PageBase.P_00_PageBase;

public class P_03_Home_Page extends P_00_PageBase {

	public P_03_Home_Page(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

//1-Locating "Top Menu bar" list element 
	public List<WebElement> topMenus (String num)
	{	
	return driver.findElements(By.xpath("(//ul[@class=\"top-menu notmobile\"]/li/a)"+num));

	}		
	
}