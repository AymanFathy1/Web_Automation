package POM_DEsign_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Home_Page {
//Create Data Field : So Create New driver	
	WebDriver driver;

//=======	
//Create Contractor for "WebDriver" in order to Not repeat it in the next Methods 
	public Home_Page (WebDriver driver) {
		this.driver = driver;//this New driver will take the value of the driver that is delivered from the execution of the Test Case
	}
//=========then	
//Test Case 1: Login without using email field
//The part of Pressing "Sign-in Button"
	
//1-Create method related to "Sign-in Button" Element
	//But Make this method from "WebElement" type not void as it'll make return statement to the TC method  in the Test_Cases package ,
	//and in the same time the TC method will send to the "Constructor" the "WebDriver driver" value that it uses,then Constructor will update the below method with that value..as below :
	public WebElement SignInBtn() { //will name this method = SignInBtn 
		//Locate the element
	return	driver.findElement(By.id("gb_70"));
//so Don't forgot : WebElement -return - driver
	}
//=============
//Test Case 3: Google Search [ Also using Constructors concept]
	
	public WebElement SearchField() { //create method with name :SearchField
		//Locate the element
	return	driver.findElement(By.name("q"));
	}
	
	public WebElement Results_text() { //create method with name :Results_text for result
		//Locate the element
	return	driver.findElement(By.id("result-stats"));
	}
}