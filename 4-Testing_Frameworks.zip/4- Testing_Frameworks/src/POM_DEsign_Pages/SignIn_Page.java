package POM_DEsign_Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SignIn_Page {

//Create Data Field : So Create New driver
	WebDriver driver;
//=======	
//Create Contractor for "WebDriver" in order to Not repeat it in the next Methods 
	public SignIn_Page (WebDriver driver) { //one argue Contractor 
		this.driver = driver; //this New driver will take the value of the driver that is delivered from the execution of the Test Case
	}
//Test Case 1: Login without using email field
//=========then	
//1-Create method related to "Email Field in sign-in Page" Element
		//But Make this method from "WebElement" type not void as it'll make return statement to the TC method in the Test_Cases package ,
		//and in the same time the TC method will send to the "Constructor" the "WebDriver driver" value that it uses then Constructor will update the below method with that value..as below :
		public WebElement EmailField () { //will name this method = EmailField..//No Need to add input of (WebDriver driver) as i already created Constructor of it 
			//Locate the element
		return	driver.findElement(By.cssSelector("input[aria-label=\"Email or phone\"]"));
//so Don't forgot : WebElement -return - driver
		
}
//2-Create method related to "Next button" Element
		
		public WebElement NextBtn () { //No Need to add input of (WebDriver driver) as i already created Constructor of it
					//Locate the element
		return	driver.findElement(By.xpath("//button[@jscontroller=\"soHxf\" and @jsname=\"LgbsSe\"]"));	
		                                   
}
		
//3-Create method related to "Actual Result" Element [Couldn't find your Google Account]
		
		public WebElement error_msg () { //No Need to add input of (WebDriver driver) as i already created Constructor of it
							//Locate the element
			return	driver.findElement(By.xpath("//div[@jsname=\"B34EJ\"]/div[@class=\"o6cuMc\"]"));
}                                         
//======================		
//Test Case 2: Get forget email url  [ Also using Constructors concept ]		

		public WebElement forgot_email () { //will name this method = forgot_email..//No Need to add input of (WebDriver driver) as i already created Constructor of it 
			//Locate the element
		return	driver.findElement(By.xpath("//button[@jsname=\"Cuz2Ue\"]"));
		
		}	
		
}
