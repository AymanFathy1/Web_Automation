package POM_Design_Test_Cases_TestNG;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import POM_DEsign_Pages.Home_Page;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;

public class NewTest {

	
	WebDriver driver; //Copy web Driver & @Before test from "T_01_How_To_Locate_Elements" Class]

	@BeforeTest //Before Test Annotation
	public void Launch_Browser()
	{

		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.navigate().to("https://www.google.com/?hl=ar");

		driver.findElement(By.partialLinkText("Eng")).click();
	}
//============================	
	
	//Test Case 3: Google Search [we took it from "T_01_How_To_Locate_Elements" Class] 
	@Test(priority = 1) 

	public  void Google_Search() { //by using TestNG No need for "static"

//if wanted to be sure of the thread that TC uses to run that test case [How to run test cases in parallel mode video] module4-20 
System.out.println(Thread.currentThread().getName());
System.out.println(Thread.currentThread().getId());
//=========	

		Home_Page home = new Home_Page(driver);
		home.SearchField().click();
		home.SearchField().sendKeys("selenium");
		home.SearchField().sendKeys(Keys.ENTER);

		//Searching on "Selenium" Result counts & result [ Ex :About 48,000,000 results (0.60 seconds)]

		System.out.println(home.Results_text().getText());	
		//System.out.println(home.Results_text().getText().contains("48,000,000"));//use assert instead as below :

//====Module 4-17
Reporter.log(home.Results_text().getText()); //this's to get TC result Report,video "How to use Reporter.log() (6:14) Module 4-17
//===
		//Soft assertion 
		SoftAssert soft = new SoftAssert(); //1st create object from soft assert
		soft.assertEquals(home.Results_text().getText().contains("10,000,000"), true); //equal boolen :the expected result should be true , means if the actual & expected =48,000,000 this's true , if not make it fail

		//System.out.println("Sumption of 2+3 = "+(2+3)+"\n"); //it's not related printing code just to test soft assert

		//soft.assertAll(); //3rd create "assertAll()" from the object to be sure that will display the real result of the TCs

		//will use try & cash to make the asserts optional [ will make the result pass even it was fail]

		System.out.println("Sumption of 2+3 = "+(2+3)+"\n");
		soft.assertAll();
		/*
		try {  // removed try & catch to & add "soft.assertAll();" separately to make this TC fail normally for video "How to use Reporter.log() (6:14) Module 4-17
			soft.assertAll();
		} catch (Error e) {
			// TODO: handle exception
			System.out.println(e.getMessage()); //print the Error

		}
		*/
	}

//==========	
	@AfterTest //After Test Annotation
	public void Close_Driver() //by using TestNG No need for "static"
	{
		driver.quit();

	}

}
