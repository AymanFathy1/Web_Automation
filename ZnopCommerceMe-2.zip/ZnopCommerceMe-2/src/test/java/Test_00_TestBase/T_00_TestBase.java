//This's a master class holds information about Driver,Browser & Properties file
package Test_00_TestBase;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

public class T_00_TestBase {
	protected WebDriver driver; //Make Declaration for driver & make it Protected
	
	//2-Create method -& name it "getProperty"-to call the values from "Properties file "
	  public String getProperty(String keyName) throws IOException  // Also create input :String variable and name it KeyName,so that every time you can add the keyname of the variable you want to call from "Properties File"  
	  {
		//1-create new object from "Properties class"
		  Properties prop = new Properties();
		
		//2-create another new object from "property class" called [FileInputStream] & add file name and path	  
		  FileInputStream fis = new FileInputStream(System.getProperty("user.dir") +"\\data.properties");
		  
	   //3-make Load to the file input stream 
		  prop.load(fis);
		  
	  //4-get the values by using the "Keyname" variable & make return statement
		return  prop.getProperty(keyName);
		  
	}

//3-Create Method–name it setProperty-to save the values that will result from execution in the “Properties file”
	  //and make it void as no need for return output
	  
	  public void setProperty(String keyName ,String Value) throws IOException  // Also create another inpute : String variable and name it Value,so that every time you can add the keyname & it's value of the variable you want to call from "Properties File"  
	  {
		//1-create new object from "Properties class"
		  Properties prop = new Properties();
		
		//2-create another new object from [FileInputStream] Class related to "property class" & add input :file name and path	  
		  FileInputStream fis = new FileInputStream(System.getProperty("user.dir") +"\\data.properties");
		  
	   //3-make Load to the file input stream 
		  prop.load(fis);
		  
	  //4-get the variable name & values
		   prop.setProperty(keyName, Value);
		   
   //5-create new object from the "FileOutputStream" class ,add input :file name and path	 
		   FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir") +"\\data.properties");
	
	 //6-use the properties object & make store to the values that i already sent it to the properties file
		   prop.store(fos, "TestComment");
	}
	    	  
@BeforeTest
public void LaunchBrowser() throws IOException  
{     //4-make calling to getProperty Method to get the variable "browserName" values which is "chrome" from [ Properties file]
	  if(getProperty("browserName").equals("chrome"))
	  {
		  WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver(); //Create New object from chrome Driver
	  }
	  else if (getProperty("browserName").equals("firefox"))
	  {		  
		  WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver(); //Create New object from firefox Driver   
	  }
		driver.manage().window().maximize();
		driver.navigate().to("https://demo.nopcommerce.com"); //Login page in new project

//Then to avoid time out  :
//Make "refresh" after every TC [by using annotation @AfterMethd]  ,
//then to wait around 2 seconds before executing the next TC [ by using implicit ] in annotation @Before test]
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}

// 
//@AfterMethod
//
//public void afterMethod () {
//	 driver.navigate().refresh(); //Make refresh after every TC
//}

@AfterTest
public void afterTest() {
	  
	driver.quit();
}

}
	
	
//@BeforeTest
//  public void beforeTest() 
//{
//	//use WebDriver Manager :
//	
//	WebDriverManager.chromedriver().setup();
//	driver = new ChromeDriver();
//	driver.manage().window().maximize();
//	driver.navigate().to("https://demo.nopcommerce.com/"); //Login page in new project
//	
////	  String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
////		System.setProperty("webdriver.chrome.driver", chromePath);
////		driver = new ChromeDriver(); //Create New object from chrome Driver
//
//		
//}
