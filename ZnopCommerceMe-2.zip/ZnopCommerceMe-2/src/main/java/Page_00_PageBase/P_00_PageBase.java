package Page_00_PageBase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class P_00_PageBase { 
//Create New Data Field with new variable called " driver"	
	protected WebDriver driver;

//Create Constructor [ and it's input is the main or basic "WebDriver driver"]
	
	public P_00_PageBase(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}