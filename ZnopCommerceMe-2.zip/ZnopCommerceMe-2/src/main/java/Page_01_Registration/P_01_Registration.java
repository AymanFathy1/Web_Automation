//This Class specialized for locating elements for Registration scenario

package Page_01_Registration;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Page_00_PageBase.P_00_PageBase;

public class P_01_Registration extends P_00_PageBase {   // The Class & it inherits from "PageBase"  
	
public P_01_Registration(WebDriver driver) {  // constructor 
		super(driver);
		// TODO Auto-generated constructor stub
	}

	//1-Create Method to LOCATE "Register Tab" Element, Then go to "T_01_Register_NewUSer" class to execute the TC & take action
	public WebElement registerTab()  {
		
		return driver.findElement(By.xpath("//a[@href=\"/register?returnUrl=%2F\"]"));
	}
	
	//2-Create Method to LOCATE "Gender Male" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action
        public WebElement genderMale()  {
		
        	return driver.findElement(By.id("gender-male"));
        }    
 
	//3-Create Method to LOCATE "Gender Female" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action
        
    	public WebElement genderFemale ()
    	{
    		return driver.findElement(By.id("gender-female"));

    	} 
	
	//4-Create Method to LOCATE "First Name " Element, Then go to "T_01_Register_NewUSer" class to Create the TC action
	
    	public WebElement firstName ()
    	{
    		return driver.findElement(By.id("FirstName"));

    	}
    	
	//5-Create Method to LOCATE "Last Name" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action
	
    	public WebElement lastName ()
    	{
    		return driver.findElement(By.id("LastName"));
    	}
 
    //6-Create Method to LOCATE "Date of birth/Day" dropdown Element, Then go to "T_01_Register_NewUSer" class to Create the TC action 	
    	
    	public WebElement dateOfBirth_Day ()
    	{
    		return driver.findElement(By.name("DateOfBirthDay"));
    	}
   
    	
    //7-Create Method to LOCATE "Date of birth/Month" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action
    	
    	public WebElement dateOfBirth_Month ()
    	{
    		return driver.findElement(By.name("DateOfBirthMonth"));
    	}
   //8-Create Method to LOCATE "Date of birth/Year" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action 	
    	public WebElement dateOfBirth_Year ()
    	{
    		return driver.findElement(By.name("DateOfBirthYear"));
    	}
    
   //9-Create Method to LOCATE "Email" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action
    	public WebElement email ()
    	{
    		return driver.findElement(By.id("Email"));
    	}
   //10-Create Method to LOCATE "Password" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action   	
    	public WebElement password ()
    	{
    		return driver.findElement(By.id("Password"));
    	}
   //11-Create Method to LOCATE "Confirm password" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action   	
    	public WebElement confirmPassword ()
    	{
    		return driver.findElement(By.id("ConfirmPassword"));
    	}
   //12-Create Method to LOCATE "Register button" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action  	
    	public WebElement register_Btn ()
    	{
    		return driver.findElement(By.id("register-button"));
    	}
    	
    	
  //13-Create Method to LOCATE "Register Success Message" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action 	
    	public List<WebElement> success_Msg ()
    	{
    	return driver.findElements(By.xpath("//div[contains(text(),\"Your registration completed\")]"));
    	}
   //14-Create Method to LOCATE "Already Exist Mail Message" Element, Then go to "T_01_Register_NewUSer" class to Create the TC action 	
    	public List<WebElement> alreadyExistMail_Msg ()
    	{
    	return driver.findElements(By.xpath("//li[contains(text(),\"The specified email already exists\")]"));
    	}
    	
	
}
