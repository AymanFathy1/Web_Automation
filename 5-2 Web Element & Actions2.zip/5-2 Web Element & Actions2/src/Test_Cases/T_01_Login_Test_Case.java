//This's another Class for another Test Cases [ but only written steps ]

package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;

import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;

import java.awt.RenderingHints.Key;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.GetCssProperty;
import org.testng.annotations.AfterTest;

public class T_01_Login_Test_Case {
 	
 //Data Field :
  WebDriver driver;
  
  @BeforeTest // we create,add adn prepare the Driver that i'll use in testing
  public void beforeTest() {
	  

		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver(); //Create New object from chrome Driver

		driver.manage().window().maximize();
		driver.navigate().to("http://the-internet.herokuapp.com/login"); //Login page in new project
	}

  
  @Test //[TC#1 for Invalid username
  public void Invalid_Username() {
	  
	  //1-Enter Invalid username
	  //2-Enter Invalid Password
	  //3-Click action on Login button
	  //4-assertion error message
  		  
  	  } 
//==========
  @Test //[TC#2 Login with Valid username ]
      
  public void Valid_Username() throws InterruptedException {
	  
	  //1-Clear Username Field
	  //2-Enter valid Password
	  
	  //3-Clear Password Field
	  //4-Enter valid Password
	  
	  driver.findElement(By.id("")).submit();
  	  
  	  } 

  @AfterTest
  public void afterTest() {
	  
	  driver.quit();
	  
  }

}
