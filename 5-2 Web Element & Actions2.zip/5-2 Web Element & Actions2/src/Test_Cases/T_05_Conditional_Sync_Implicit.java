//This 4th Class for 4th Test Cases[ check if element visible/Presence on ""DOM Page"" by another Technique ]
//But will use Conditional Synchronization 
package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;
import Pages.P_02_Checkboxes_Page;

import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.GetCssProperty;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class T_05_Conditional_Sync_Implicit {
 	
 //Data Field :
  WebDriver driver;
  
  @BeforeTest // we create,add & prepare the Driver that i'll use in testing
  public void beforeTest() {
	  
		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver(); //Create New object from chrome Driver

		driver.manage().window().maximize();
		driver.navigate().to("https://www.facebook.com/"); //Facebook home page URL
		
	//To use Conditional Sync Implicit "
		driver.manage().timeouts().implicitlyWait(7,TimeUnit.SECONDS);
	}
  
  @Test //[TC#1 Need to make assertion for "Sign Up" to check if it's visible on "DOM Page" 
       //There are 2 Steps : press "Create New Account" then Press "Sign Up" the press "Close" button or X
          
  public void Presence_IN_DOMPage() throws InterruptedException {
	  
	//1-Locate "Create New Account" button & Take action Click : 
	  driver.findElement(By.id("u_0_2")).click();
	  
	  
	//2-Locate "Sign Up"button element + use [.size() > 0] method :if size count > 0 so element so "Sign up" button NOT visible/Present so it's true & if present so it's false

	//Due to "Sign Up"button appears in DOM page after above action so the result should be true so i used [assertTrue()] ya3ne baolo akedly en .size() > 0) is true thus TC is pass
	  assertTrue(driver.findElements(By.xpath("//button[@name=\"websubmit\"]")).size() > 0);
	  System.out.println("Debug0");
	  
	//3-Locate "Close X" button & tack click action
	  driver.findElement(By.xpath("//img[@class=\"_8idr img\"]")).click();

	  System.out.println("Debug1");
	  
	  //Thread.sleep(1000); // Look at the last comment
	  //then use assertTrue again to check if it's still present in Dom page
	  assertTrue(driver.findElements(By.xpath("//button[@name=\"websubmit\"]")).size() == 0);
	  //if .size() > 0) so TC should be fail as it's indeed doesn't present in DOM page      
	  //if made it .size() == 0) so TC should be fail as it's indeed doesn't present in DOM page
	  //assertTrue(driver.findElements(By.xpath("//button[@name=\"websubmit\"]")).size() > 0);
  
	  System.out.println("Debug2");
	  
	  //the last assert will fail so the TC will fail as Synchronization Implicit disadvantage is its only deal with one condition So to avoid that either to :
	 //1-add "Thread.sleep(1000);" before the last assertion:ya3ne ba2olo wait 1 second before checking visibility of Sign up button in Dom page,
	    //till selenium press "close x" button 3lashan usually there's a little delay.
	//2-Use Explicit Sync   
  	  } 

  @AfterTest
  public void afterTest() {
	  
	  driver.quit();	  
  }
}
