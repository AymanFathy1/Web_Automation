//This 6th Class for 6th Test Cases[ Multiple Windows ]
//But will use Conditional Synchronization 
package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;
import Pages.P_02_Checkboxes_Page;

import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.GetCssProperty;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class T_06_Multi_Windows {
 	
 //Data Field :
  WebDriver driver;
  
  @BeforeTest // we create,add & prepare the Driver that i'll use in testing
  public void beforeTest() {
	  
		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver(); //Create New object from chrome Driver

		driver.manage().window().maximize();
		driver.navigate().to("http://the-internet.herokuapp.com/windows");
		
	//To use Conditional Sync Implicit "
		driver.manage().timeouts().implicitlyWait(7,TimeUnit.SECONDS);
	}
  
  @Test //[TC#1 Handling New Tab & Switch between tabs
          
  public void Handling_New_Tab() throws InterruptedException {
	  
	  System.out.println(driver.getCurrentUrl());
	  System.out.println(driver.getTitle());
	  System.out.println(driver.getWindowHandle());
	  
	  //1-Locate Element of "Click Here" tab
	  driver.findElement(By.xpath("//a[@target=\"_blank\" and text() =\"Click Here\"]")).click();
	
	  Thread.sleep(2000);
	  
	  Set<String> windowHandles = driver.getWindowHandles();
	  
	  //Then create array type string & save it it the WindowHandles
	  ArrayList<String> tabs = new ArrayList<>(windowHandles);
	  
	  driver.switchTo().window(tabs.get(1)); // (1) is the 2nd tab (0) is the 1st tab
	  
	  System.out.println(driver.getCurrentUrl());
	  System.out.println(driver.getTitle());
	  System.out.println(driver.getWindowHandle());
  	  } 

  @AfterTest
  public void afterTest() {
	  
	  driver.quit();	  
  }
}
