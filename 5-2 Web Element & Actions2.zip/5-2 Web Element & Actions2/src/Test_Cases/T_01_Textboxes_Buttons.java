//This Class for Test Cases
//Creating Automation TCs by using POM Design Pattern & "TestNG" [ Also using Constructors concept]
//page we'll log in is : http://the-internet.herokuapp.com/login
package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;

import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.GetCssProperty;
import org.testng.annotations.AfterTest;

public class T_01_Textboxes_Buttons {
 	
 //Data Field :
  WebDriver driver;
  
  @BeforeTest // we create,add adn prepare the Driver that i'll use in testing
  public void beforeTest() {
	  

		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver(); //Create New object from chrome Driver

		driver.manage().window().maximize();
		driver.navigate().to("http://the-internet.herokuapp.com/login"); //Login page in new project
	}

  
  @Test //[TC#1 to get URL of tab "Powered by Elemental Selenium" in the page under testing]
  public void Get_URL() {
  		  
  	 P_01_Login_Page p01 = new P_01_Login_Page(driver); //create new object from "P_01_Login_Page" to use the elements that exist in it 
  		  p01.Elemntal_Selenuim().getText();// to get the URL in the Element [Elemental Selenium]
  		  String URL; //create String variable to save the value that will come from below 
  		URL= p01.Elemntal_Selenuim().getAttribute("href"); //to get the URL in the Element ["http://elementalselenium.com/"]
  		
  	  //use Assertion to compare actual & expected result of the above test case :
  	  assertEquals(URL,"http://elementalselenium.com/"); //if the value come from URL variable = the URL "http://elementalselenium.com/" so the case is pass or true
  	  
  	  } 
//==========
  @Test //[TC#2 Pressing Login button while No Data Entered [ username & password)
       //to get the Error " Your username is invalid!" background color "Red"]
  public void Get_COLOR() throws InterruptedException {
	  
 //1-create new object from "P_01_Login_Page" to use the elements that exist in it 
  	 P_01_Login_Page p01 = new P_01_Login_Page(driver); 
  	 
//2-Need to make action for Clicking "Login" button
  	p01.FLogin_Btn().click(); //p01:is the object name -FLogin_Btn : is the method name of elemnt exit in "P_01_Login_Page" Class - .click() : is the Action
  	 
    Thread.sleep(2000);  //Create thread sleep for 2 second between click login action & Error 
  	
//3-The Error that will appear when press login button while no data is exist in username & passward
  	  String Color; //create String variable to save the value that will come from below 	  
  	  Color= p01.Flash_Error().getCssValue("background-color");// use ".getCssValue to get the background color of the Error from element [ i took "background-color" copy from the element]
  	
  	 System.out.println(Color); // to print the Color value then run code adn get the color values from result then create the new assersion:
  	 

 //4-After running the cod get the color values from result & make the below :
  	 assertEquals(Color, "rgba(198, 15, 19, 1)");
  	  
  	  } 

  @AfterTest
  public void afterTest() {
	  
	  driver.quit();
	  
  }

}
