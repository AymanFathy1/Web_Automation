//This 3rd Class for 3rdTest Cases
//Creating Automation TCs by using POM Design Pattern & "TestNG" [ Also using Constructors concept]
//Page that we'll test : http://the-internet.herokuapp.com/dropdown
package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;
import Pages.P_02_Checkboxes_Page;

import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.GetCssProperty;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class T_03_Dropdown_list {
 	
 //Data Field :
  WebDriver driver;
  
  @BeforeTest // we create,add & prepare the Driver that i'll use in testing
  public void beforeTest() {
	  
		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver(); //Create New object from chrome Driver

		driver.manage().window().maximize();
		driver.navigate().to("http://the-internet.herokuapp.com/dropdown"); //Drop Down List page in new project
	}
  
  @Test //[TC#1 Test DropDown List http://the-internet.herokuapp.com/dropdown]
       //there are 2 choice in the drop down list
      //first way to select Option 2 then 1 then the default [ But take care the default is disable or not selected ]
 
  public void Dropdown_Method_One() throws InterruptedException {

	  //1-find the element of option 2 by value :
	driver.findElement(By.xpath("//option[@value=\"2\"]")).click();
	
	 //create thread sleep to make around 2 seconds before doing the next action
	Thread.sleep(2000);
	
	  //2-find the element of option 1 by link text :	
	driver.findElement(By.xpath("//option[text()='Option 1']")).click();
	
	Thread.sleep(2000);
	
	//3-also you can select the disabled option "please select an option�
	//we use findElements(arg0) with s : if need to select group of elements have the same locator
	
	driver.findElements(By.xpath("//select[@id=\"dropdown\"]/option")).get(0).click(); //add get(0) index 0
	Thread.sleep(2000);
	
////But Take care the default option on the website is disabled so :
	//.getOptions() methods : used to return a list of web Elements
   //.isEnabled() methods : means if the option is enabled so result is true but if it wasn't so false ,
  //and due to the default option is disabled so result will be false so i'll use assertFalse() ya3ne ba2olo akkedly in el result will be false & if false make tc result pass
	
	assertFalse(driver.findElement(By.xpath("//option[text()='Please select an option']")).isEnabled());
	//Option 1 is enabled so [.isEnabled()] will be true so i'll use assertTrue ya3ne ba2olo akkedly in el result will be true & if true make tc result pass
	assertTrue(driver.findElement(By.xpath("//option[text()='Option 1']")).isEnabled()); 
  	  } 
 //========
  @Test //[TC#2 to select options by ["select" class & methods]
        //Second way to select Option 2 then 1 then the default [ But take care the default is disable or not selected ]
      
public void Dropdown_Method_Two() throws InterruptedException {

   //1-Create New object and make the input of this object to be the Element Locator
   //we created object to allow me then to select any option i want
   Select select = new Select(driver.findElement(By.id("dropdown"))); //"Select" is a reserved class in selenium
 
   //2-Then From above object make 2nd step to select the option 2 by [select.selectByValue(arg0);] method:
   select.selectByValue("2");; //[select.selectByValue(arg0);] is a reserved method by Selenium
	
   Thread.sleep(2000);
   
   //3-From the above object select the option 1 by [selectByVisibleText(arg0);] method:
   select.selectByVisibleText("Option 1");
   
   Thread.sleep(2000);
   
  //4-also you can select the disabled option "please select an option�
   select.selectByIndex(0);  
   Thread.sleep(2000);   
 
   assertFalse(select.getOptions().get(0).isEnabled()); 
   assertTrue(select.getOptions().get(1).isEnabled()); 
 
  } 
    
  @AfterTest
  public void afterTest() {
	  
	  driver.quit();	  
  }
}
