//This 4th Class for 4th Test Cases[ check if element visible on ""UI"" ]
//Creating Automation TCs by using POM Design Pattern & "TestNG" [ Also using Constructors concept]
//Page that we'll test : https://www.facebook.com/pages/create/?ref_type=registration_form
package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;
import Pages.P_02_Checkboxes_Page;

import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.GetCssProperty;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class T_04_Check_Visibilty {
 	
 //Data Field :
  WebDriver driver;
  
  @BeforeTest // we create,add & prepare the Driver that i'll use in testing
  public void beforeTest() {
	  
		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver(); //Create New object from chrome Driver

		driver.manage().window().maximize();
		driver.navigate().to("https://www.facebook.com/pages/create/?ref_type=registration_form"); //Face book Create new Page URL
	}
  
  @Test //[TC#1 Need to make assertion for "Login button" to check if it's visible on ""UI""   (https://www.facebook.com/pages/create/?ref_type=registration_form
          
  public void Visibility() throws InterruptedException {
	  
	  //1-Locate Login button element + use isDisplayed() method :if login button visible so it's true & if Not so false
	  Thread.sleep(2000);
	  //Due to the Login button appears in UI so the result should be true so i used [assertTrue()] ya3ne baolo akedly in isDeiplayed is true thus TC is pass
      assertTrue(driver.findElement(By.xpath("//button[@id=\"loginbutton\"]")).isDisplayed());
      
      //2-Locate "Join or log in to Facebook" arrow element & take Click action to be collapsed + use isDisplayed() method :if login button AFTER this action visible so it's true & if Not so false
      driver.findElement(By.xpath("//a[@id=\"u_0_2\"]")).click();
      Thread.sleep(2000);
     //Due to the Login button after this action disappears in UI so the result should be false so i used [assertFalse()] ya3ne baolo akedly in isDeiplayed is false thus TC is pass
      assertFalse(driver.findElement(By.xpath("//button[@id=\"loginbutton\"]")).isDisplayed());
      
  	  } 

  @AfterTest
  public void afterTest() {
	  
	  driver.quit();	  
  }
}
