//This another Class for another Test Cases
//Creating Automation TCs by using POM Design Pattern & "TestNG" [ Also using Constructors concept]
//Page that we'll test : http://the-internet.herokuapp.com/checkboxes
package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;
import Pages.P_02_Checkboxes_Page;

import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.GetCssProperty;
import org.testng.annotations.AfterTest;

public class T_02_checkboxes {
 	
 //Data Field :
  WebDriver driver;
  
  @BeforeTest // we create,add adn prepare the Driver that i'll use in testing
  public void beforeTest() {
	  

		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver(); //Create New object from chrome Driver

		driver.manage().window().maximize();
		driver.navigate().to("http://the-internet.herokuapp.com/checkboxes"); //check boxes page in new project
	}

  
  @Test //[TC#1 Test Check boxes in page http://the-internet.herokuapp.com/checkboxes]
//there are 2 check boxes , the 1st one is unchecked , we need to select both
  //But with new change related to video "Checkboxes & Radio - Apply POM Design Pattern and use dynamic locators"
  
  public void checkbox() {
  	//1-create boolean variable in order to define "check boxes" selection with True & false 
	  boolean check;
	
   //2- create new object from checbox page , after creating class "P_02_Checkboxes_Page"...video ""Checkboxes & Radio - Apply POM Design Pattern and use dynamic locators"
	  P_02_Checkboxes_Page p02 = new P_02_Checkboxes_Page(driver);
	  
	  //if option 1 is checked so result will be true but if unchecked = false
	  check = p02.checkbox("1").isSelected();
	//Check box 1 in the page is not checked So the value will be received from above is false so use [assertFalse(check)] so if value from above is false this step is passed
	  assertFalse(check);	  
	  
  //3-then make Action click on the "check box 1"
	  p02.checkbox("1").click();
	  //so use again [.isSelected()] should value = true
	  check = p02.checkbox("1").isSelected(); //use isSelected() to check if the check box is selected
	  //Check box 1 is now checked So the value will be received from above is true so use [assertTrue(check)] so if value from above is true this step is passed
	  assertTrue(check);
	  	  	  
  //4-Then after selecting Option 1 , need to check if the option 2 is Unselected [ so use isSelected()]
	  check= p02.checkbox("2").isSelected();
	  assertTrue(check); //
 
	  
	 //2-if option 1 is checked so result will be true but if unchecked = false
//		  check=  driver.findElement(By.xpath("(//input[@type=\"checkbox\"])[1]")).isSelected(); //use isSelected() to check is the check box is selected? if yes so it's true
//		//Check box 1 in the page is not checked So the value will be received from above is false so use [assertFalse(check)] so if value from above is false this step is passed
//		  assertFalse(check); 
	  
	   //3-then make Action click on the "check box 1"
//		  driver.findElement(By.xpath("(//input[@type=\"checkbox\"])[1]")).click();
//		  //so use again [.isSelected()] should value = true 
//		  check=  driver.findElement(By.xpath("(//input[@type=\"checkbox\"])[1]")).isSelected(); //use isSelected() to check if the check box is selected
//		//Check box 1 is now checked So the value will be received from above is true so use [assertTrue(check)] so if value from above is true this step is passed
//		  assertTrue(check);	
	  
//	  //4-Then after selecting Option 1 , need to check if the option 2 is Unselected [ so use isSelected()]
//	  check=  driver.findElement(By.xpath("(//input[@type=\"checkbox\"])[2]")).isSelected(); //
//	  assertTrue(check); //  
	  
  	  } 
    
  @AfterTest
  public void afterTest() {
	  
	  //driver.quit();
	  
  }

}
