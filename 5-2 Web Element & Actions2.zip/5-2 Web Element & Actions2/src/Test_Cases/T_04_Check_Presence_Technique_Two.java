//This 4th Class for 4th Test Cases[ check if element visible/Presence on ""DOM Page"" by another Technique ]
//Page that we'll test : https://www.facebook.com/
package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;
import Pages.P_02_Checkboxes_Page;

import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.server.handler.GetCssProperty;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class T_04_Check_Presence_Technique_Two {
 	
 //Data Field :
  WebDriver driver;
  
  @BeforeTest // we create,add & prepare the Driver that i'll use in testing
  public void beforeTest() {
	  
		String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver(); //Create New object from chrome Driver

		driver.manage().window().maximize();
		driver.navigate().to("https://www.facebook.com/"); //Facebook home page URL
	}
  
  @Test //[TC#1 Need to make assertion for "Sign Up" to check if it's visible on "DOM Page" 
       //There are 2 Steps : press "Create New Account" then Press "Sign Up" the press "Close" button or X
          
  public void Presence_IN_DOMPage() throws InterruptedException {
	  
	//1-Locate "Create New Account" button & Take action Click : 
	  driver.findElement(By.id("u_0_2")).click();
	  
	  
	//2-Locate "Sign Up"button element + use [.size() > 0] method :if size count > 0 so element so "Sign up" button NOT visible/Present so it's true & if present so it's false
	  Thread.sleep(2000);
	//Due to "Sign Up"button appears in DOM page after above action so the result should be true so i used [assertTrue()] ya3ne baolo akedly en .size() > 0) is true thus TC is pass
	  assertTrue(driver.findElements(By.xpath("//button[@name=\"websubmit\"]")).size() > 0);
    
	//3-Locate "Close X" button & tack click action
	  driver.findElement(By.xpath("//img[@class=\"_8idr img\"]")).click();
	  Thread.sleep(2000);
	  //then use assertTrue again to check if it's still present in Dom page
	  assertTrue(driver.findElements(By.xpath("//button[@name=\"websubmit\"]")).size() > 0);
	  //if .size() > 0) so TC should be fail as it's indeed doesn't present in DOM page      
	  //if made it .size() == 0) as below so TC should be fail as it's indeed doesn't present in DOM page
	//assertTrue(driver.findElements(By.xpath("//button[@name=\"websubmit\"]")).size() == 0);	  
  	  } 

  @AfterTest
  public void afterTest() {
	  
	  driver.quit();	  
  }
}
