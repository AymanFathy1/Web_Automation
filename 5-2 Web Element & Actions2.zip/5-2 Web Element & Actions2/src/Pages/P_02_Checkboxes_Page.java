//This 2nd Class for elements
//Checkboxes & Radio - Apply POM Design Pattern and use dynamic locators
package Pages;

import static org.testng.Assert.assertFalse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P_02_Checkboxes_Page {
//Create Data Field : So Create New driver variable which will take the value from the  main driver that added also in the below constructor 
	WebDriver driver;
	
//Create constructor that will contain the Driver that i'll in Execution	
	public P_02_Checkboxes_Page(WebDriver driver) // the driver her is the main driver
	{
		this.driver = driver; //first driver is the new variable created in Data field , second driver is the main driver 
		
	}

//create Methods for elements :
	
//Method -Related to TC# 1 with new change is to make number of checkbox is dynamic as the Tester who will add it in the Test case
	
	public WebElement checkbox(String num) {
		
		return driver.findElement(By.xpath("(//input[@type=\"checkbox\"])["+num+"]")); //instead of write [1] to present checbox number , will add variable num so in the test case the Tester can change it freely	
	}

	     //check=  driver.findElement(By.xpath("(//input[@type=\"checkbox\"])[1]")).isSelected(); 
		
	
}
