//This 3rd  Class for elements related to Test class "T_05_Conditional_Sync_Explicit_3 "
//If condition only requires "By" object, we should handle this in "POM Design Pattern"
package Pages;

import static org.testng.Assert.assertFalse;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class P_05_Facebook_HomePage {
//Create Data Field : So Create New driver variable which will take the value from the  main driver that added also in the below constructor 
	WebDriver driver;
	
//Create constructor that will contain the Driver that i'll in Execution	
	public P_05_Facebook_HomePage(WebDriver driver) // the driver her is the main driver
	{
		this.driver = driver; //first driver is the new variable created in Data field , second driver is the main driver 
		
	}

//create Methods for elements :
	
//Method -Related to TC# 5 Explicit wait 3 //Create webelelment for button"Create New Account"
	
	public WebElement CreateNewAccount() 
	{	
		return driver.findElement(By.id("u_0_2"));	
	}
//Method -Related also to TC# 5 Explicit wait 3 //Create webelelment for button"Sign Up"
	//but due to we used driver.findElements - with s- we need to use method [List<WebElement>] as below below :
	
	public List<WebElement> SignUpList() //List<WebElement> is a reserved method in selenium and i named it SignUpList 
	{
	
	return driver.findElements(By.xpath("//button[@name=\"websubmit\"]"));
		
	}
	
//Method -Related also to TC# 5 Explicit wait 3 //Create webelelment for button"Close x"
		
		public WebElement CloseBtn() 
		{
		
		return driver.findElement(By.xpath("//img[@class=\"_8idr img\"]"));
			
		}	
	
//Method -Related also to TC# 5 Explicit wait 3 //Create webelelment for button"Sign Up" again to check if Visible/present in DOM page ,BUT
//when we used Explicit while creating method [ wait.until(ExpectedConditions.numberOfElementsToBe(By.xpath("//button[@name=\"websubmit\"]"), 0));] ,
//we used "By Locator" in the method , so can't used Webelement in locator But i'll use "By" Object as below 	
	
	public By SignUpLocator()  // By locator object
	{
		return By.xpath("//button[@name=\"websubmit\"]");
	}
	
}
