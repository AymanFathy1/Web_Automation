//This Class for elements
package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P_01_Login_Page {
//Create Data Field : So Create New driver variable which will take the value from the  main driver that added also in the below constructor 
	WebDriver driver;
	
//Create constructor that will contain the Driver that i'll in Execution	
	public P_01_Login_Page(WebDriver driver) // the driver her is the main driver
	{
		this.driver = driver; //first driver is the new variable created in Data field , second driver is the main driver 
		
	}

//create Methods for elements :
	
//Method -Related to TC# 1 - for Element of "Elemntal_Selenuim" that exit in the page
	
	public WebElement Elemntal_Selenuim() {
		
		return driver.findElement(By.xpath("//a[@target=\"_blank\"]"));		
	}
//==========
//Method -Related to TC# 2 -for Element of Login button
	
			public WebElement FLogin_Btn() {
				
				return driver.findElement(By.cssSelector("button[type=\"submit\"]"));		
			}
	
//Method -Related to TC# 2 -for Element of Error " Your username is invalid!" background color "Red"
	
		public WebElement Flash_Error() {
			
			return driver.findElement(By.id("flash"));		
		}

}
